---
name: wiki-init
description: Initialize or update a project knowledge base (wiki/). Caches architecture, features, conventions, and error history to save tokens on repeated codebase scans. Trigger when user says "init wiki", "create knowledge base", "update wiki", "wiki-init", or when starting a new project.
user-invocable: true
argument-hint: "[--update]"
---

# wiki-init

为当前项目初始化或更新 `wiki/` 知识库——项目代码的结构化缓存。

## 核心理念

知识库 = 项目代码的**索引 + 缓存**。避免每次对话都全局扫描源码。先查 wiki，查不到再读代码。

| 目标 | 手段 |
|------|------|
| 节约 Token | 预存架构/路由/功能信息，按需查阅替代全局扫描 |
| 避免重犯 | 记录曾犯错误及修复方式 |
| 防止冲突 | 新增功能前先查功能清单，发现重复及时确认 |
| 快速定位 | 每个文件/模块的职责一目了然 |

## 执行步骤

### 步骤 0：判断模式

- 用户说 `wiki-init` / `初始化知识库` / `创建 wiki` → **全量初始化**（步骤 1-4）
- 用户说 `wiki-init --update` / `更新知识库` / `补充 wiki` → **增量更新**（步骤 5）
- 如果 `wiki/` 目录已存在但用户坚持全量初始化，先询问确认（会覆盖已有内容）

### 步骤 1：扫描项目

按顺序执行，最多并行 3 个操作：

1. 读 `CLAUDE.md`（如有）——提取已记录的技术栈、结构、规范
2. `Glob` 扫描一层目录结构（`*`、`**/*.go` 或 `**/*.ts` 等按语言调整）
3. 读依赖清单（`go.mod` / `package.json` / `requirements.txt` / `Cargo.toml` 等）
4. 读入口文件（`main.go` / `index.ts` / `app.py` / `src/main.*` 等）——提取路由/命令注册
5. 读核心业务文件（handler/controller/service 层）——提取功能列表

### 步骤 2：创建目录结构

```
wiki/
├── README.md                  # 本知识库的用途、规则、目录概览
├── architecture/
│   ├── README.md              # 索引
│   ├── overview.md            # 项目总览、技术栈、目录树、数据流
│   └── routes.md              # 路由/命令→处理函数→业务层映射（纯库项目可省略）
├── features/
│   ├── README.md              # 索引
│   └── inventory.md           # 已实现功能清单，标注状态
├── conventions/
│   ├── README.md              # 索引
│   └── coding.md              # 编码规范、命名约定、UI 设计参数
└── errors/
    ├── README.md              # 索引
    └── known-errors.md        # 错误记录（初始为空模板）
```

### 步骤 3：填充内容

每个文件的**最小内容要求**：

**wiki/README.md**
```markdown
# 项目知识库
## 使用规则
- 先查 wiki，查不到再扫描源码
- 代码变更涉及 wiki 内容时同步更新
- 过时知识及时删除，新知识追加写入
## 目录
（列出各子目录及用途）
```

**architecture/overview.md** — 必含：项目一句话描述、语言/框架/关键依赖、目录树（含每个文件的一句话职责）、请求→处理→响应的数据流简述

**architecture/routes.md** — 必含表格：

| 方法 | 路径 | Handler | Service | 模板/响应 | 功能 |
|------|------|---------|---------|-----------|------|

（CLI/库项目用命令/公开函数表格替代）

**features/inventory.md** — 按模块分组，每条功能标注 `已实现` / `规划中`，含入口路径

**conventions/coding.md** — 从 CLAUDE.md 和代码中提取：分层约定、命名风格、错误处理模式、UI 设计参数（如有前端）

**errors/known-errors.md** — 初始模板：
```markdown
# 错误记录

> 暂无记录。遇到错误后按下方模板追加。

## 模板

## 错误 N：简短标题
**日期**：YYYY-MM-DD
**现象**：表面问题
**根因**：根本原因
**定位**：如何快速定位
**修复**：具体命令或代码
**预防**：避免再犯
```

### 步骤 4：更新 CLAUDE.md

在 CLAUDE.md 末尾追加（如尚未包含）：

```markdown
## 知识库（wiki/）

项目结构化知识库。**每次对话先浏览 wiki/ 目录结构**。

| 场景 | 先查 |
|------|------|
| 定位代码 | `wiki/architecture/` |
| 新增功能 | `wiki/features/inventory.md` |
| 遇到报错 | `wiki/errors/known-errors.md` |
| 编码风格 | `wiki/conventions/` |

**维护**：代码变更涉及 wiki 内容时同步更新，过时条目删除，新知识追加。
```

### 步骤 5：增量更新

只操作变化的部分：
- 新功能 → 追加到 `features/inventory.md`
- 架构变更 → 更新 `architecture/` 对应条目
- 新错误 → 按模板追加到 `errors/known-errors.md`
- 过时内容 → 删除对应条目/段落
- 完成后告知改动了哪些文件

## 裁减原则

| 项目类型 | 裁减 |
|----------|------|
| 单文件脚本 | 只建 `wiki/README.md` + `errors/known-errors.md` |
| 无 UI 的库/CLI | 省略 `conventions/coding.md` 中的 UI 设计参数 |
| 无路由的库项目 | 省略 `architecture/routes.md`，在 overview 中说明公开 API |
| 纯前端项目 | `routes.md` 改为页面/组件路由 |

## 注意事项

- 知识库与 CLAUDE.md **互补而非重复**——CLAUDE.md 是每次加载的精简指引，wiki 是按需查阅的详细缓存
- 不要为了"完整"而填充空泛内容——每个条目必须有实际查阅价值
- 创建完成后用一句话告知用户各文件的内容概要
