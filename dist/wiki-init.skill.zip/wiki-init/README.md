# wiki-init — 项目知识库初始化工具

为 Claude Code 项目自动创建 `wiki/` 知识库，缓存项目架构、功能清单、编码约定和错误记录，避免每次对话都全局扫描源码，节约 Token。

## 安装

### 方式一：npx skill-import（推荐）

```bash
# 从本地目录安装
npx skill-import ./wiki-init/

# 从 SKILL.md 文件直接安装
npx skill-import ./wiki-init/SKILL.md
```

### 方式二：手动安装

```bash
# 安装为用户级 skill（所有项目可用）
cp -r wiki-init/ ~/.claude/skills/

# 或安装为项目级 skill（仅当前项目可用）
cp -r wiki-init/ .claude/skills/
```

### 方式三：zip 安装

```bash
# 打包
zip -r wiki-init.skill.zip wiki-init/

# 安装
npx skill-import wiki-init.skill.zip
```

### 验证安装

在 Claude Code 中执行：

```
/skills          # 应看到 wiki-init
/wiki-init       # 直接调用
```

如果 `/wiki-init` 不出现，重启 Claude Code 会话。

## 使用

```
/wiki-init              # 全量初始化——扫描项目并创建完整知识库
/wiki-init --update     # 增量更新——只追加新内容，不覆盖已有
```

或者用自然语言：

```
初始化知识库
更新 wiki
补充知识库
```

## 知识库结构

初始化后项目下生成：

```
wiki/
├── README.md                  # 知识库用途、规则、目录索引
├── architecture/              # 架构文档
│   ├── overview.md            # 项目总览、技术栈、数据流
│   └── routes.md              # 路由→Handler→Service 映射
├── features/
│   └── inventory.md           # 已实现功能清单
├── conventions/
│   └── coding.md              # 编码规范、设计约定
└── errors/
    └── known-errors.md        # 曾犯错误及修复记录
```

## 维护

- 代码变更涉及 wiki 内容时，Claude 会自动同步更新
- 旧知识过期时删除，新知识追加写入已有文件
- 不需要手动维护——Claude 在对话中根据 `/wiki-init --update` 或代码变更自动处理

## 兼容性

- Claude Code（所有版本）
- 支持所有编程语言和项目类型
- 根据项目规模自动裁减（单文件脚本只建最小结构）
